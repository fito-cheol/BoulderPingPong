using Godot;
using System;
using System.Collections.Generic;
using Godot.Collections;

public partial class GameManager : Node
{
	[Signal]
	public delegate void GameStartedEventHandler();
	
	[Signal]
	public delegate void GameEndedEventHandler();
	
	[Signal]
	public delegate void ScoreUpdatedEventHandler(int playerScore, int aiScore);

	[Export]
	public Node PoseReceiver { get; set; }
	
	[Export]
	public Node2D Ball { get; set; }
	
	[Export]
	public Node2D PlayerPaddle { get; set; }
	
	[Export]
	public Node2D AIPaddle { get; set; }
	
	[Export]
	public Label ScoreLabel { get; set; }
	
	[Export]
	public Label StatusLabel { get; set; }

	[Export]
	public Label DebugLabel { get; set; }
 
	// 게임 설정
	private float gameWidth = 1920.0f;
	private float gameHeight = 1080.0f;
	private float ballSpeed = 400.0f;
	private float paddleSpeed = 300.0f;
	private float aiSpeed = 250.0f;

	// 게임 상태
	private bool gameActive = false;
	private int playerScore = 0;
	private int aiScore = 0;
	private Vector2 ballVelocity = Vector2.Zero;

	// 포즈 데이터 처리
	private List<Godot.Collections.Dictionary> playerHands = new List<Godot.Collections.Dictionary>();
	private List<Godot.Collections.Dictionary> playerFeet = new List<Godot.Collections.Dictionary>();
	private double lastPoseTime = 0.0;
	private double poseTimeout = 5.0; // 5초 동안 포즈가 없으면 게임 일시정지

	private int playerCount = 0;
	private bool serverConnected = false;

	public override void _Ready()
	{
		//make this deferred ready
		CallDeferred(nameof(DeferredReady));
	}

	public void DeferredReady()
	{ 
		// 포즈 데이터 수신 연결
		if (PoseReceiver != null)
		{
			Signals.onPoseDataReceived += OnPoseDataReceived;
		}
		
		// 게임 초기화
		InitializeGame();
		
		GD.Print("GameManager 초기화 완료");
	}

	public override void _Process(double delta)
	{
		if (!gameActive)
			return;
		
		// 포즈 데이터 타임아웃 체크
		if (Time.GetUnixTimeFromSystem() - lastPoseTime > poseTimeout)
		{
			StatusLabel.Text = "플레이어를 찾을 수 없습니다...";
			playerCount = 0;
			UpdateDebugStatus();
			return;
		}
		
		StatusLabel.Text = "게임 진행 중";
		UpdateDebugStatus();
		
		// 게임 업데이트
		UpdateBall((float)delta);
		UpdateAIPaddle((float)delta);
		CheckCollisions();
	}

	private void InitializeGame()
	{
		// 게임 요소 초기화
		Ball.Position = new Vector2(gameWidth / 2.0f, gameHeight / 2.0f);
		ballVelocity = new Vector2(ballSpeed, 0).Rotated((float)GD.RandRange(0.785f, 0.785f)); // Pi/4 radians   
		GD.Print("ballVelocity: ", ballVelocity);
		PlayerPaddle.Position = new Vector2(100.0f, gameHeight / 2.0f);
		AIPaddle.Position = new Vector2(gameWidth - 100.0f, gameHeight / 2.0f);
		
		UpdateScoreDisplay();
		gameActive = true;
		EmitSignal(nameof(GameStarted));
	} 
	private void OnPoseDataReceived(GodotObject poseData)
	{
		lastPoseTime = Time.GetUnixTimeFromSystem(); 
		// Convert GodotObject to Variant, then to Dictionary
		Variant poseVariant = Variant.CreateFrom(poseData);
		if (poseVariant.VariantType == Variant.Type.Dictionary)
		{
			var poseDict = poseVariant.AsGodotDictionary();
			if (poseDict.ContainsKey("players"))
			{
				var playersVariant = poseDict["players"];
				if (playersVariant.VariantType == Variant.Type.Array)
				{
					var players = playersVariant.AsGodotArray();
					playerCount = players.Count;
					serverConnected = true;
					if (players.Count > 0)
					{
						var playerVariant = players[0];
						if (playerVariant.VariantType == Variant.Type.Dictionary)
						{
							var player = playerVariant.AsGodotDictionary();
							// 손과 발 데이터 추출
							playerHands.Clear();
							playerFeet.Clear();
							if (player.ContainsKey("hands"))
							{
								var handsVariant = player["hands"];
								if (handsVariant.VariantType == Variant.Type.Array)
								{
									var hands = handsVariant.AsGodotArray();
									foreach (var hand in hands)
									{
										if (hand.VariantType == Variant.Type.Dictionary)
										{
											var handDict = hand.AsGodotDictionary();
											if (handDict.ContainsKey("x") && handDict.ContainsKey("y"))
											{
												playerHands.Add(handDict);
											}
										}
									}
								}
							}
							if (player.ContainsKey("feet"))
							{
								var feetVariant = player["feet"];
								if (feetVariant.VariantType == Variant.Type.Array)
								{
									var feet = feetVariant.AsGodotArray();
									foreach (var foot in feet)
									{
										if (foot.VariantType == Variant.Type.Dictionary)
										{
											var footDict = foot.AsGodotDictionary();
											if (footDict.ContainsKey("x") && footDict.ContainsKey("y"))
											{
												playerFeet.Add(footDict);
											}
										}
									}
								}
							}
							// 플레이어 패들 업데이트
							UpdatePlayerPaddle();
						}
					}
					UpdateDebugStatus();
				}
				else
				{
					playerCount = 0;
					serverConnected = true;
					UpdateDebugStatus();
				}
			}
			else
			{
				playerCount = 0;
				serverConnected = true;
				UpdateDebugStatus();
			}
		}
		else
		{
			playerCount = 0;
			serverConnected = false;
			UpdateDebugStatus();
		}
	}

	private void UpdatePlayerPaddle()
	{
		if (playerHands.Count > 0)
		{
			// 손 위치를 기반으로 패들 위치 결정
			var handPositions = new List<Vector2>();
			
			foreach (var hand in playerHands)
			{
				if (hand.ContainsKey("x") && hand.ContainsKey("y"))
				{
					// 카메라 좌표를 게임 좌표로 변환
					float gameX = Convert.ToSingle(hand["x"]) * gameWidth / 3.66f; // WALL_WIDTH
					float gameY = Convert.ToSingle(hand["y"]) * gameHeight / 3.66f; // WALL_HEIGHT
					handPositions.Add(new Vector2(gameX, gameY));
				}
			}
			
			if (handPositions.Count > 0)
			{
				// 평균 손 위치 계산
				var avgPosition = Vector2.Zero;
				foreach (var pos in handPositions)
				{
					avgPosition += pos;
				}
				avgPosition /= handPositions.Count;
				
				// 패들 위치 업데이트 (Y축만)
				float targetY = Mathf.Clamp(avgPosition.Y, 50, gameHeight - 50);
				PlayerPaddle.Position = new Vector2(PlayerPaddle.Position.X, 
					Mathf.Lerp(PlayerPaddle.Position.Y, targetY, 0.1f));
			}
		}
	}

	private void UpdateBall(float delta)
	{
		Ball.Position += ballVelocity * delta;
		
		// 벽 충돌 체크
		if (Ball.Position.Y <= 0 || Ball.Position.Y >= gameHeight)
		{
			ballVelocity.Y = -ballVelocity.Y;
			Ball.Position = new Vector2(Ball.Position.X, Mathf.Clamp(Ball.Position.Y, 0, gameHeight));
		}
	}

	private void UpdateAIPaddle(float delta)
	{
		// AI 패들은 공을 따라가도록 구현
		float targetY = Ball.Position.Y;
		targetY = Mathf.Clamp(targetY, 50, gameHeight - 50);
		
		AIPaddle.Position = new Vector2(AIPaddle.Position.X,
			Mathf.Lerp(AIPaddle.Position.Y, targetY, aiSpeed * delta / 100.0f));
	}

	private void CheckCollisions()
	{
		// 패들과 공의 충돌 체크
		var ballRect = new Rect2(Ball.Position - new Vector2(10, 10), new Vector2(20, 20));
		var playerRect = new Rect2(PlayerPaddle.Position - new Vector2(10, 50), new Vector2(20, 100));
		var aiRect = new Rect2(AIPaddle.Position - new Vector2(10, 50), new Vector2(20, 100));
		
		// 플레이어 패들 충돌
		if (ballRect.Intersects(playerRect))
		{
			ballVelocity.X = Mathf.Abs(ballVelocity.X);
			ballVelocity.Y += GD.RandRange(-50, 50);
			ballVelocity = ballVelocity.Normalized() * ballSpeed;
		}
		
		// AI 패들 충돌
		if (ballRect.Intersects(aiRect))
		{
			ballVelocity.X = -Mathf.Abs(ballVelocity.X);
			ballVelocity.Y += GD.RandRange(-50, 50);
			ballVelocity = ballVelocity.Normalized() * ballSpeed;
		}
		
		// 점수 체크
		if (Ball.Position.X <= 0)
		{
			aiScore++;
			ResetBall();
			UpdateScoreDisplay();
		}
		else if (Ball.Position.X >= gameWidth)
		{
			playerScore++;
			ResetBall();
			UpdateScoreDisplay();
		}
	}

	private void ResetBall()
	{
		Ball.Position = new Vector2(gameWidth / 2.0f, gameHeight / 2.0f);
		ballVelocity = new Vector2(ballSpeed, 0).Rotated((float)GD.RandRange(-0.785f, 0.785f)); // -Pi/4 to Pi/4 radians
		
		// 점수에 따라 방향 결정
		if (playerScore > aiScore)
		{
			ballVelocity.X = -Mathf.Abs(ballVelocity.X);
		}
		else
		{
			ballVelocity.X = Mathf.Abs(ballVelocity.X);
		}
	}

	private void UpdateScoreDisplay()
	{
		ScoreLabel.Text = $"플레이어: {playerScore}  |  AI: {aiScore}";
		EmitSignal(nameof(ScoreUpdated), playerScore, aiScore);
	}

	public void RestartGame()
	{
		playerScore = 0;
		aiScore = 0;
		InitializeGame();
	}

	public override void _Input(InputEvent @event)
	{
		if (@event.IsActionPressed("ui_accept"))
		{
			RestartGame();
		}
		else if (@event.IsActionPressed("ui_cancel"))
		{
			gameActive = false;
			EmitSignal(nameof(GameEnded));
		}
	}

	private void UpdateDebugStatus()
	{
		string status = "";
		status += $"서버 연결: {(serverConnected ? "O" : "X")}\n";
		status += $"플레이어 수: {playerCount}\n";
		double sinceLastPose = Time.GetUnixTimeFromSystem() - lastPoseTime;
		status += $"마지막 포즈 수신: {sinceLastPose:F1}초 전";
		DebugLabel.Text = status;
	}
} 
