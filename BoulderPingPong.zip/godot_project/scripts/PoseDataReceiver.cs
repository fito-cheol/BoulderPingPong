using Godot;
using System;
using Godot.Collections;
using System.Collections.Generic; 

public partial class PoseDataReceiver : Node
{ 
    public Action<GodotObject> PoseDataReceived;
 
    [Export]
    public Label DebugJsonLabel;
    private HttpRequest httpRequest;
    private string poseDataUrl = "http://localhost:8080/pose_data";
    private Timer updateTimer;

    private Dictionary currentPoseData = new Dictionary();
    private bool isConnected = false;
    private bool isRequesting = false;

    public override void _Ready()
    {
        // HTTP 요청 노드 생성
        httpRequest = new HttpRequest();
        AddChild(httpRequest);
        httpRequest.RequestCompleted += OnRequestCompleted;
        
        // 타이머 설정 (10 FPS로 업데이트 - 서버 부하 감소)
        updateTimer = new Timer();
        AddChild(updateTimer);
        updateTimer.WaitTime = 1.0f / 10.0f; // 10 FPS
        updateTimer.Timeout += RequestPoseData;
        updateTimer.Start();

        // 최초 요청을 한 프레임 뒤에!
        CallDeferred(nameof(RequestPoseData));
        
        GD.Print("PoseDataReceiver 초기화 완료");
        GD.Print("서버 URL: ", poseDataUrl);
    }

    private void RequestPoseData()
    {
        GD.Print($"RequestPoseData called, isRequesting={isRequesting}");
        if (isRequesting)
            return;
        isRequesting = true;
        var error = httpRequest.Request(poseDataUrl);
        if (error != Error.Ok)
        {
            GD.Print("HTTP 요청 실패: ", error);
            isRequesting = false; // 실패 시에도 반드시 초기화
        }
    }

    private void OnRequestCompleted(long result, long responseCode, string[] headers, byte[] body)
    {
        isRequesting = false; // 무조건 맨 앞에!
        /*
        GD.Print("OnRequestCompleted");
        GD.Print("result: ", result);
        GD.Print("responseCode: ", responseCode);
        GD.Print("headers: ", headers);
        GD.Print("body: ", body.GetStringFromUtf8());
        */
        
        if (result != (long)HttpRequest.Result.Success)
        {
            GD.Print("HTTP 요청 실패: ", result);
            isConnected = false;
            return;
        }
        
        if (responseCode != 200)
        {
            GD.Print("HTTP 응답 오류: ", responseCode);
            isConnected = false;
            return;
        }
        
        // JSON 파싱
        Json json = new Json();
        var parseResult = json.Parse(body.GetStringFromUtf8());
        if (parseResult != Error.Ok)    
        {
            GD.Print("JSON 파싱 실패: ", parseResult);
            return;
        }
        
        var poseData = json.Data;
        if (poseData.VariantType == Variant.Type.Dictionary)
        {   
            currentPoseData = poseData.AsGodotDictionary();
            isConnected = true;
            if (DebugJsonLabel != null)
            {
                string jsonStr = Json.Stringify(poseData);
                if (jsonStr.Length > 1000)
                    jsonStr = jsonStr.Substring(0, 1000) + "\n... (생략)";
                DebugJsonLabel.Text = jsonStr;
            }
            Signals.onPoseDataReceived(poseData.AsGodotObject());
        }
        
        else
        {
            GD.Print("잘못된 포즈 데이터 형식");
        }
        GD.Print("OnRequestCompleted");
    }

    public Dictionary GetCurrentPoseData()
    {
        return currentPoseData;
    }

    public bool IsServerConnected()
    {
        return isConnected;
    }

    public int GetPlayerCount()
    {
        if (currentPoseData.ContainsKey("players"))
        {
            var playersVariant = currentPoseData["players"];
            if (playersVariant.VariantType == Variant.Type.Array)
            {
                var players = playersVariant.AsGodotArray();
                return players.Count;
            }
        }
        return 0;
    }

    public Godot.Collections.Array GetPlayerHands(int playerIndex)
    {
        if (playerIndex < GetPlayerCount())
        {
            var playersVariant = currentPoseData["players"];
            if (playersVariant.VariantType == Variant.Type.Array)
            {
                var players = playersVariant.AsGodotArray();
                if (playerIndex < players.Count)
                {
                    var playerVariant = players[playerIndex];
                    if (playerVariant.VariantType == Variant.Type.Dictionary)
                    {
                        var player = playerVariant.AsGodotDictionary();
                        if (player.ContainsKey("hands"))
                        {
                            var handsVariant = player["hands"];
                            if (handsVariant.VariantType == Variant.Type.Array)
                            {
                                return handsVariant.AsGodotArray();
                            }
                        }
                    }
                }
            }
        }
        return new Godot.Collections.Array();
    }

    public Godot.Collections.Array GetPlayerFeet(int playerIndex)
    {
        if (playerIndex < GetPlayerCount())
        {
            var playersVariant = currentPoseData["players"];
            if (playersVariant.VariantType == Variant.Type.Array)
            {
                var players = playersVariant.AsGodotArray();
                if (playerIndex < players.Count)
                {
                    var playerVariant = players[playerIndex];
                    if (playerVariant.VariantType == Variant.Type.Dictionary)
                    {
                        var player = playerVariant.AsGodotDictionary();
                        if (player.ContainsKey("feet"))
                        {
                            var feetVariant = player["feet"];
                            if (feetVariant.VariantType == Variant.Type.Array)
                            {
                                return feetVariant.AsGodotArray();
                            }
                        }
                    }
                }
            }
        }
        return new Godot.Collections.Array();
    }

    public Dictionary GetPlayerHead(int playerIndex)
    {
        if (playerIndex < GetPlayerCount())
        {
            var playersVariant = currentPoseData["players"];
            if (playersVariant.VariantType == Variant.Type.Array)
            {
                var players = playersVariant.AsGodotArray();
                if (playerIndex < players.Count)
                {
                    var playerVariant = players[playerIndex];
                    if (playerVariant.VariantType == Variant.Type.Dictionary)
                    {
                        var player = playerVariant.AsGodotDictionary();
                        if (player.ContainsKey("head"))
                        {
                            var headVariant = player["head"];
                            if (headVariant.VariantType == Variant.Type.Dictionary)
                            {
                                return headVariant.AsGodotDictionary();
                            }
                        }
                    }
                }
            }
        }
        return new Dictionary();
    }

    public Dictionary GetPlayerBody(int playerIndex)
    {
        if (playerIndex < GetPlayerCount())
        {
            var playersVariant = currentPoseData["players"];
            if (playersVariant.VariantType == Variant.Type.Array)
            {
                var players = playersVariant.AsGodotArray();
                if (playerIndex < players.Count)
                {
                    var playerVariant = players[playerIndex];
                    if (playerVariant.VariantType == Variant.Type.Dictionary)
                    {
                        var player = playerVariant.AsGodotDictionary();
                        if (player.ContainsKey("body"))
                        {
                            var bodyVariant = player["body"];
                            if (bodyVariant.VariantType == Variant.Type.Dictionary)
                            {
                                return bodyVariant.AsGodotDictionary();
                            }
                        }
                    }
                }
            }
        }
        return new Dictionary();
    }
} 