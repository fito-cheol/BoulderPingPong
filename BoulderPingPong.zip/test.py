with open('c:/Users/TypingCat/Documents/취업/개인프로젝트/Pingpong/BoulderPingPong/test.py', "rb") as f:
    print("파일 정상 열림!")