import json
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import http.server
from camera import Camera, find_available_cameras
from calibration import calibrate_projector
import pygame
import numpy as np
import cv2
from config import SCREEN_WIDTH, SCREEN_HEIGHT, FULLSCREEN

class PoseDataHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, *args, camera=None, server_instance=None, **kwargs):
        self.camera = camera
        self.server_instance = server_instance
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        if self.path == '/pose_data':
            start_time = time.time()
            # CORS 헤더 설정
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            players_data = self.camera.get_full_pose_data()
            pose_data = {
                'timestamp': time.time(),
                'players': players_data
            }
            response = json.dumps(pose_data).encode()
            self.send_header('Content-Length', str(len(response)))
            self.end_headers()
            self.wfile.write(response)
            self.wfile.flush()
            # 연결 상태 및 응답 시간 업데이트
            if self.server_instance:
                self.server_instance.connected = True
                self.server_instance.last_request_time = time.time()
                elapsed_ms = int((time.time() - start_time) * 1000)
                self.server_instance.last_response_time_ms = elapsed_ms
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_OPTIONS(self):
        # CORS preflight 요청 처리
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def log_message(self, format, *args):
        # 로그 출력 비활성화
        pass

class GodotPoseServer:
    def __init__(self, camera, host='localhost', port=8080):
        self.camera = camera
        self.host = host
        self.port = port
        self.server = None
        self.server_thread = None
        self.running = False
        self.connected = False
        self.last_request_time = 0
        self.last_response_time_ms = 0  # 최근 응답 시간(ms)
    
    def start_server(self):
        """HTTP 서버 시작"""
        def handler_factory(camera, server_instance):
            def create_handler(*args, **kwargs):
                return PoseDataHandler(*args, camera=camera, server_instance=server_instance, **kwargs)
            return create_handler
        
        self.server = http.server.HTTPServer((self.host, self.port), handler_factory(self.camera, self))
        self.running = True
        
        print(f"Godot 연동 서버가 시작되었습니다: http://{self.host}:{self.port}")
        
        try:
            self.server.serve_forever()
        except KeyboardInterrupt:
            print("서버를 종료합니다.")
        finally:
            self.stop_server()
    
    def start_server_thread(self):
        """별도 스레드에서 서버 시작"""
        self.server_thread = threading.Thread(target=self.start_server, daemon=True)
        self.server_thread.start()
    
    def stop_server(self):
        """서버 종료"""
        self.running = False
        if self.server:
            self.server.shutdown()
            self.server.server_close()
    
    def is_connected(self):
        """연결 상태 확인"""
        return self.connected and (time.time() - self.last_request_time) < 5.0

class CameraSelectionDialog:
    def __init__(self, parent):
        self.parent = parent
        self.selected_camera_index = None
        self.dialog = None
        
    def show(self):
        """카메라 선택 다이얼로그 표시"""
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.title("카메라 선택")
        self.dialog.geometry("500x400")
        self.dialog.resizable(False, False)
        self.dialog.transient(self.parent)
        self.dialog.grab_set()
        
        # 중앙 정렬
        self.dialog.geometry("+%d+%d" % (
            self.parent.winfo_rootx() + self.parent.winfo_width()//2 - 250,
            self.parent.winfo_rooty() + self.parent.winfo_height()//2 - 200
        ))
        
        self.setup_ui()
        
        # 다이얼로그가 닫힐 때까지 대기
        self.parent.wait_window(self.dialog)
        return self.selected_camera_index
    
    def setup_ui(self):
        """UI 구성"""
        main_frame = ttk.Frame(self.dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 제목
        title_label = ttk.Label(main_frame, text="카메라 선택", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 20))
        
        # 검색 중 표시
        self.search_label = ttk.Label(main_frame, text="카메라 검색 중...", font=("Arial", 10))
        self.search_label.pack(pady=(0, 10))
        
        # 진행률 표시
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.pack(fill=tk.X, pady=(0, 20))
        self.progress.start()
        
        # 카메라 목록 프레임
        list_frame = ttk.Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))
        
        # 트리뷰 생성
        columns = ('index', 'name', 'type', 'resolution', 'fps')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=8)
        
        # 컬럼 설정
        self.tree.heading('index', text='인덱스')
        self.tree.heading('name', text='카메라 이름')
        self.tree.heading('type', text='타입')
        self.tree.heading('resolution', text='해상도')
        self.tree.heading('fps', text='FPS')
        
        self.tree.column('index', width=60)
        self.tree.column('name', width=150)
        self.tree.column('type', width=80)
        self.tree.column('resolution', width=100)
        self.tree.column('fps', width=60)
        
        # 스크롤바
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.select_button = ttk.Button(button_frame, text="선택", command=self.select_camera, state="disabled")
        self.select_button.pack(side=tk.RIGHT, padx=(10, 0))
        
        self.cancel_button = ttk.Button(button_frame, text="취소", command=self.cancel)
        self.cancel_button.pack(side=tk.RIGHT)
        
        # 더블클릭 이벤트
        self.tree.bind('<Double-1>', self.on_double_click)
        
        # 카메라 검색 시작
        self.search_cameras()
    
    def search_cameras(self):
        """카메라 검색 (별도 스레드에서 실행)"""
        def search_thread():
            try:
                # 빠른 카메라 검색 (타임아웃 적용)
                available_cameras = self.find_cameras_fast()
                
                # UI 업데이트는 메인 스레드에서
                self.dialog.after(0, self.update_camera_list, available_cameras)
                
            except Exception as e:
                self.dialog.after(0, self.show_error, str(e))
        
        threading.Thread(target=search_thread, daemon=True).start()
    
    def find_cameras_fast(self):
        """빠른 카메라 검색 (타임아웃 적용)"""
        available_cameras = []
        
        # 더 안전한 검색 범위 설정
        max_camera_index = 5  # 일반적으로 5개 정도면 충분
        
        for i in range(max_camera_index):
            try:
                # OpenCV 경고 메시지 억제
                import warnings
                warnings.filterwarnings("ignore", category=UserWarning)
                
                cap = cv2.VideoCapture(i, cv2.CAP_ANY)
                if cap.isOpened():
                    # 빠른 프레임 읽기 시도 (타임아웃 적용)
                    cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 500)  # 0.5초로 단축
                    cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 500)  # 0.5초로 단축
                    
                    # 프레임 읽기 시도 (더 안전한 방법)
                    try:
                        ret, frame = cap.read()
                        if ret and frame is not None and frame.size > 0:
                            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                            fps = cap.get(cv2.CAP_PROP_FPS)
                            
                            # 카메라 이름 가져오기
                            camera_name = self.get_camera_name_windows(i)
                            camera_type = "USB 카메라" if i > 0 else "내장 카메라"
                            
                            available_cameras.append({
                                'index': i,
                                'name': camera_name,
                                'type': camera_type,
                                'resolution': f"{width}x{height}",
                                'fps': fps
                            })
                    except Exception as frame_error:
                        print(f"카메라 {i} 프레임 읽기 실패: {frame_error}")
                        pass
                    
                    cap.release()
                else:
                    # 연속으로 2개 이상 실패하면 중단 (더 빠른 종료)
                    if i > 1 and len(available_cameras) == 0:
                        break
                        
            except Exception as e:
                print(f"카메라 {i} 검색 중 오류: {e}")
                continue
        
        return available_cameras
    
    def get_camera_name_windows(self, index):
        """Windows에서 카메라 이름을 가져오는 함수"""
        try:
            import subprocess
            result = subprocess.run(['powershell', '-Command',
                                   'Get-WmiObject -Class Win32_PnPEntity | Where-Object {$_.Name -like "*camera*" -or $_.Name -like "*webcam*"} | Select-Object Name'],
                                   capture_output=True, text=True, timeout=2)
            cameras = result.stdout.strip().split('\n')[2:]  # 헤더 제거
            if index < len(cameras):
                return cameras[index].strip()
        except:
            pass
        return f"카메라 {index}"
    
    def update_camera_list(self, cameras):
        """카메라 목록 업데이트"""
        self.progress.stop()
        self.progress.pack_forget()
        
        if not cameras:
            self.search_label.config(text="사용 가능한 카메라가 없습니다.")
            return
        
        self.search_label.config(text=f"{len(cameras)}개의 카메라를 찾았습니다.")
        
        # 트리뷰에 카메라 추가
        for camera in cameras:
            self.tree.insert('', 'end', values=(
                camera['index'],
                camera['name'],
                camera['type'],
                camera['resolution'],
                f"{camera['fps']:.1f}"
            ))
        
        # 첫 번째 카메라 선택
        if cameras:
            first_item = self.tree.get_children()[0]
            self.tree.selection_set(first_item)
            self.select_button.config(state="normal")
    
    def show_error(self, error_msg):
        """오류 표시"""
        self.progress.stop()
        self.progress.pack_forget()
        self.search_label.config(text=f"카메라 검색 중 오류: {error_msg}")
    
    def select_camera(self):
        """카메라 선택"""
        selection = self.tree.selection()
        if selection:
            item = self.tree.item(selection[0])
            camera_index = int(item['values'][0])
            self.selected_camera_index = camera_index
            self.dialog.destroy()
    
    def on_double_click(self, event):
        """더블클릭으로 카메라 선택"""
        self.select_camera()
    
    def cancel(self):
        """취소"""
        self.selected_camera_index = None
        self.dialog.destroy()

class GodotServerGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Godot 연동 서버")
        self.root.geometry("800x500")
        self.root.resizable(True, True)
        self.root.minsize(600, 400)
        
        # 서버 관련 변수
        self.camera = None
        self.pose_server = None
        self.server_running = False
        
        self.setup_ui()
        
    def setup_ui(self):
        """UI 구성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.N, tk.S, tk.E, tk.W))
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        main_frame.grid_rowconfigure(4, weight=1)  # 로그 프레임이 늘어나도록
        main_frame.grid_columnconfigure(0, weight=1)
        main_frame.grid_columnconfigure(1, weight=1)
        
        # 제목
        title_label = ttk.Label(main_frame, text="Godot 연동 서버", font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # 서버 설정 프레임
        settings_frame = ttk.LabelFrame(main_frame, text="서버 설정", padding="10")
        settings_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # 호스트 설정
        ttk.Label(settings_frame, text="호스트:").grid(row=0, column=0, sticky=tk.W)
        self.host_var = tk.StringVar(value="localhost")
        host_entry = ttk.Entry(settings_frame, textvariable=self.host_var, width=15)
        host_entry.grid(row=0, column=1, padx=(10, 0))
        
        # 포트 설정
        ttk.Label(settings_frame, text="포트:").grid(row=1, column=0, sticky=tk.W, pady=(10, 0))
        self.port_var = tk.StringVar(value="8080")
        port_entry = ttk.Entry(settings_frame, textvariable=self.port_var, width=15)
        port_entry.grid(row=1, column=1, padx=(10, 0), pady=(10, 0))
        
        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=20)
        
        # 카메라 선택 버튼
        self.camera_select_button = ttk.Button(button_frame, text="카메라 선택", command=self.select_camera)
        self.camera_select_button.grid(row=0, column=0, padx=(0, 10))
        
        # 시작/중지 버튼
        self.start_button = ttk.Button(button_frame, text="서버 시작", command=self.start_server)
        self.start_button.grid(row=0, column=1, padx=(0, 10))
        
        self.stop_button = ttk.Button(button_frame, text="서버 중지", command=self.stop_server, state="disabled")
        self.stop_button.grid(row=0, column=2, padx=(0, 10))
        
        # 캘리브레이션 버튼
        self.calib_button = ttk.Button(button_frame, text="캘리브레이션", command=self.run_calibration)
        self.calib_button.grid(row=0, column=3, padx=(0, 10))
        
        # 카메라 화면 버튼
        self.camera_button = ttk.Button(button_frame, text="카메라 화면", command=self.show_camera_view)
        self.camera_button.grid(row=0, column=4)
        
        # 상태 프레임
        status_frame = ttk.LabelFrame(main_frame, text="서버 상태", padding="10")
        status_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # 카메라 정보 표시
        self.camera_info_var = tk.StringVar(value="카메라가 선택되지 않음")
        camera_info_label = ttk.Label(status_frame, textvariable=self.camera_info_var, font=("Arial", 10))
        camera_info_label.grid(row=0, column=0, sticky=tk.W)
        
        # 상태 표시
        self.status_var = tk.StringVar(value="대기 중")
        status_label = ttk.Label(status_frame, textvariable=self.status_var, font=("Arial", 10))
        status_label.grid(row=1, column=0, sticky=tk.W, pady=(5, 0))
        
        # 연결 상태
        self.connection_var = tk.StringVar(value="연결 없음")
        connection_label = ttk.Label(status_frame, textvariable=self.connection_var, font=("Arial", 10))
        connection_label.grid(row=2, column=0, sticky=tk.W, pady=(5, 0))
        
        # URL 표시
        self.url_var = tk.StringVar(value="")
        url_label = ttk.Label(status_frame, textvariable=self.url_var, font=("Arial", 9), foreground="blue")
        url_label.grid(row=3, column=0, sticky=tk.W, pady=(5, 0))
        
        # 로그 프레임
        log_frame = ttk.LabelFrame(main_frame, text="로그", padding="10")
        log_frame.grid(row=4, column=0, columnspan=2, sticky=(tk.N, tk.S, tk.E, tk.W), pady=(0, 10))
        log_frame.grid_rowconfigure(0, weight=1)
        log_frame.grid_columnconfigure(0, weight=1)
        
        # 로그 텍스트
        self.log_text = tk.Text(log_frame)
        log_scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        log_scrollbar.grid(row=0, column=1, sticky="ns")
        
        # 상태 업데이트 타이머
        self.update_status()
    
    def select_camera(self):
        """카메라 선택"""
        dialog = CameraSelectionDialog(self.root)
        camera_index = dialog.show()
        
        if camera_index is not None:
            try:
                self.log_message(f"카메라 {camera_index} 초기화 중...")
                self.camera = Camera(camera_index=camera_index)
                self.log_message(f"카메라 {camera_index} 초기화 완료")
                
                # 카메라 정보 업데이트
                self.camera_info_var.set(f"카메라 {camera_index} - {self.camera.camera_width}x{self.camera.camera_height}")
                
            except Exception as e:
                self.log_message(f"카메라 초기화 실패: {e}")
                messagebox.showerror("오류", f"카메라 초기화 실패:\n{e}")
                self.camera = None
                self.camera_info_var.set("카메라 초기화 실패")
        
    def log_message(self, message):
        """로그 메시지 추가"""
        self.log_text.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {message}\n")
        self.log_text.see(tk.END)
        
    def start_server(self):
        """서버 시작"""
        if not self.camera:
            messagebox.showwarning("경고", "먼저 카메라를 선택하세요.")
            return
            
        try:
            # 서버 시작
            host = self.host_var.get()
            port = int(self.port_var.get())
            
            self.pose_server = GodotPoseServer(self.camera, host, port)
            self.pose_server.start_server_thread()
            
            self.server_running = True
            self.status_var.set("실행 중")
            self.url_var.set(f"http://{host}:{port}/pose_data")
            
            self.start_button.config(state="disabled")
            self.stop_button.config(state="normal")
            
            self.log_message(f"서버가 시작되었습니다: http://{host}:{port}")
            
        except Exception as e:
            self.log_message(f"서버 시작 실패: {e}")
            messagebox.showerror("오류", f"서버 시작 실패:\n{e}")
    
    def stop_server(self):
        """서버 중지"""
        if self.pose_server:
            self.pose_server.stop_server()
            self.server_running = False
            self.status_var.set("중지됨")
            self.connection_var.set("연결 없음")
            self.url_var.set("")
            
            self.start_button.config(state="normal")
            self.stop_button.config(state="disabled")
            
            self.log_message("서버가 중지되었습니다.")
    
    def run_calibration(self):
        """캘리브레이션 실행"""
        if not self.camera:
            messagebox.showwarning("경고", "먼저 카메라를 초기화하세요.")
            return
        
        try:
            self.log_message("캘리브레이션 시작...")
            
            # Pygame 초기화
            pygame.init()
            screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN if FULLSCREEN else 0)
            pygame.display.set_caption("캘리브레이션")
            
            # 캘리브레이션 실행
            homography = calibrate_projector(self.camera, screen)
            
            if homography is not None:
                self.log_message("캘리브레이션 완료")
                messagebox.showinfo("완료", "캘리브레이션이 완료되었습니다.")
            else:
                self.log_message("캘리브레이션 취소됨")
                messagebox.showinfo("취소", "캘리브레이션이 취소되었습니다.")
                
        except Exception as e:
            self.log_message(f"캘리브레이션 실패: {e}")
            messagebox.showerror("오류", f"캘리브레이션 실패:\n{e}")
        finally:
            pygame.quit()
    
    def show_camera_view(self):
        """카메라 화면 표시 (디버깅용)"""
        if not self.camera:
            messagebox.showwarning("경고", "먼저 카메라를 초기화하세요.")
            return
        
        try:
            self.log_message("카메라 화면 시작...")
            
            # Pygame 초기화
            pygame.init()
            screen = pygame.display.set_mode((800, 600))
            pygame.display.set_caption("카메라 화면 (ESC로 종료)")
            
            clock = pygame.time.Clock()
            running = True
            
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            running = False
                
                # 카메라에서 프레임 가져오기
                frame = self.camera.get_frame()
                if frame is not None:
                    # OpenCV BGR을 RGB로 변환
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    
                    # numpy 배열을 pygame surface로 변환
                    frame_surface = pygame.surfarray.make_surface(frame_rgb.swapaxes(0, 1))
                    
                    # 화면에 표시
                    screen.blit(frame_surface, (0, 0))
                    pygame.display.flip()
                
                clock.tick(30)  # 30 FPS
            
            self.log_message("카메라 화면 종료")
            
        except Exception as e:
            self.log_message(f"카메라 화면 실패: {e}")
            messagebox.showerror("오류", f"카메라 화면 실패:\n{e}")
        finally:
            pygame.quit()
    
    def update_status(self):
        """상태 업데이트"""
        if self.pose_server and self.server_running:
            if self.pose_server.is_connected():
                self.connection_var.set("연결됨")
            else:
                self.connection_var.set("연결 대기 중...")
            # 최근 응답 시간 표시
            resp_ms = self.pose_server.last_response_time_ms
            self.status_var.set(f"실행 중 (최근 응답: {resp_ms} ms)")
        
        # 1초마다 업데이트
        self.root.after(1000, self.update_status)
    
    def run(self):
        """GUI 실행"""
        self.root.mainloop()
        
        # 종료 시 정리
        if self.pose_server:
            self.pose_server.stop_server()
        if self.camera:
            self.camera.release()

def main():
    """메인 함수"""
    app = GodotServerGUI()
    app.run()

if __name__ == "__main__":
    main() 