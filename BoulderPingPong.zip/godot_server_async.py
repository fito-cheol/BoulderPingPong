import json
import time
import asyncio
import aiohttp
from aiohttp import web
from camera import Camera
from calibration import calibrate_projector
import pygame
import numpy as np
from config import SCREEN_WIDTH, SCREEN_HEIGHT, FULLSCREEN

class AsyncGodotPoseServer:
    def __init__(self, camera, host='localhost', port=8080):
        self.camera = camera
        self.host = host
        self.port = port
        self.app = None
        self.runner = None
        self.connected = False
        self.last_request_time = 0
        self.running = False
    
    async def handle_pose_data(self, request):
        """포즈 데이터 요청 처리"""
        try:
            # 포즈 데이터 가져오기
            players_data = self.camera.get_full_pose_data()
            
            # Godot에서 사용할 수 있는 형태로 데이터 변환
            pose_data = {
                'timestamp': time.time(),
                'players': players_data
            }
            
            # 연결 상태 업데이트
            self.connected = True
            self.last_request_time = time.time()
            
            # JSON 응답 전송
            return web.json_response(pose_data)
            
        except Exception as e:
            print(f"포즈 데이터 처리 오류: {e}")
            return web.json_response({'error': str(e)}, status=500)
    
    async def handle_health(self, request):
        """헬스 체크 엔드포인트"""
        return web.json_response({
            'status': 'ok',
            'timestamp': time.time(),
            'connected': self.is_connected
        })
    
    def create_app(self):
        """aiohttp 앱 생성"""
        self.app = web.Application()
        self.app.router.add_get('/pose_data', self.handle_pose_data)
        self.app.router.add_get('/health', self.handle_health)
        
        # CORS 설정
        async def cors_middleware(app, handler):
            async def middleware(request):
                response = await handler(request)
                response.headers['Access-Control-Allow-Origin'] = '*'
                response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
                response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
                return response
            return middleware
        
        self.app.middlewares.append(cors_middleware)
        return self.app
    
    async def start_server(self):
        """서버 시작"""
        self.create_app()
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        
        site = web.TCPSite(self.runner, self.host, self.port)
        await site.start()
        
        print(f"비동기 Godot 연동 서버가 시작되었습니다: http://{self.host}:{self.port}")
        print("Godot에서 다음 URL로 포즈 데이터를 요청할 수 있습니다:")
        print(f"http://{self.host}:{self.port}/pose_data")
        
        self.running = True
        
        # 서버 실행 유지
        while self.running:
            await asyncio.sleep(1)
    
    def stop_server(self):
        """서버 종료"""
        self.running = False
        if self.runner:
            asyncio.create_task(self.runner.cleanup())
    
    def is_connected(self):
        """연결 상태 확인"""
        return self.connected and (time.time() - self.last_request_time) < 5.0

async def pygame_event_loop(screen, pose_server):
    """Pygame 이벤트 루프 (비동기)"""
    clock = pygame.time.Clock()
    running = True
    
    while running:
        # Pygame 이벤트 처리
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
        
        # 화면 업데이트
        screen.fill((0, 0, 0))
        
        # 상태 표시
        font = pygame.font.Font(None, 36)
        status_text = f"비동기 서버 실행 중 - {pose_server.host}:{pose_server.port}"
        text_surface = font.render(status_text, True, (255, 255, 255))
        screen.blit(text_surface, (50, 50))
        
        # 연결 상태 표시
        if pose_server.is_connected():
            conn_text = "연결됨"
            conn_color = (0, 255, 0)
        else:
            conn_text = "연결 대기 중..."
            conn_color = (255, 255, 0)
        
        conn_surface = font.render(conn_text, True, conn_color)
        screen.blit(conn_surface, (50, 100))
        
        # 추가 정보 표시
        info_text = f"ESC: 종료 | FPS: {clock.get_fps():.1f}"
        info_surface = font.render(info_text, True, (200, 200, 200))
        screen.blit(info_surface, (50, 150))
        
        pygame.display.flip()
        clock.tick(30)  # 30 FPS로 제한
        
        # 비동기 처리 허용
        await asyncio.sleep(0.001)
    
    return running

async def main_async():
    """비동기 메인 함수"""
    print("비동기 Godot 연동 서버를 시작합니다...")
    
    try:
        # 카메라 초기화
        camera = Camera()
        
        # Pygame 초기화 (캘리브레이션용)
        pygame.init()
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN if FULLSCREEN else 0)
        pygame.display.set_caption("비동기 Godot 연동 서버")
        
        # 캘리브레이션
        print("\n=== 캘리브레이션 시작 ===")
        homography = calibrate_projector(camera, screen)
        
        if homography is None:
            print("캘리브레이션이 취소되었습니다. 프로그램을 종료합니다.")
            return
        
        # 서버 시작
        pose_server = AsyncGodotPoseServer(camera)
        
        print("\n=== 서버 실행 중 ===")
        print("Godot에서 포즈 데이터를 받아갈 수 있습니다.")
        print("ESC를 눌러서 서버를 종료하세요.")
        
        # 서버와 Pygame 이벤트 루프를 동시에 실행
        server_task = asyncio.create_task(pose_server.start_server())
        pygame_task = asyncio.create_task(pygame_event_loop(screen, pose_server))
        
        # 두 태스크 중 하나라도 완료되면 종료
        done, pending = await asyncio.wait(
            [server_task, pygame_task],
            return_when=asyncio.FIRST_COMPLETED
        )
        
        # 남은 태스크 정리
        for task in pending:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
    except Exception as e:
        print(f"오류 발생: {e}")
    finally:
        if 'pose_server' in locals():
            pose_server.stop_server()
        if 'camera' in locals():
            camera.release()
        pygame.quit()

def main():
    """메인 함수"""
    try:
        asyncio.run(main_async())
    except KeyboardInterrupt:
        print("\n서버를 종료합니다...")

if __name__ == "__main__":
    main() 