import json
import time
import threading
import http.server
from camera import Camera
from calibration import calibrate_projector
import pygame
import numpy as np
from config import SCREEN_WIDTH, SCREEN_HEIGHT, FULLSCREEN

class PoseDataHandler(http.server.BaseHTTPRequestHandler):
    def __init__(self, *args, camera=None, server_instance=None, **kwargs):
        self.camera = camera
        self.server_instance = server_instance
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        if self.path == '/pose_data':
            # CORS 헤더 설정
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
            
            # 포즈 데이터 가져오기
            players_data = self.camera.get_full_pose_data()
            
            # Godot에서 사용할 수 있는 형태로 데이터 변환
            pose_data = {
                'timestamp': time.time(),
                'players': players_data
            }
            
            # 연결 상태 업데이트
            if self.server_instance:
                self.server_instance.connected = True
                self.server_instance.last_request_time = time.time()
            
            # JSON 응답 전송
            self.wfile.write(json.dumps(pose_data).encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_OPTIONS(self):
        # CORS preflight 요청 처리
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def log_message(self, format, *args):
        # 로그 출력 비활성화 (선택사항)
        pass

class GodotPoseServer:
    def __init__(self, camera, host='localhost', port=8080):
        self.camera = camera
        self.host = host
        self.port = port
        self.server = None
        self.server_thread = None
        self.running = False
        self.connected = False
        self.last_request_time = 0
    
    def start_server(self):
        """HTTP 서버 시작"""
        def handler_factory(camera, server_instance):
            def create_handler(*args, **kwargs):
                return PoseDataHandler(*args, camera=camera, server_instance=server_instance, **kwargs)
            return create_handler
        
        self.server = http.server.HTTPServer((self.host, self.port), handler_factory(self.camera, self))
        self.running = True
        
        print(f"Godot 연동 서버가 시작되었습니다: http://{self.host}:{self.port}")
        print("Godot에서 다음 URL로 포즈 데이터를 요청할 수 있습니다:")
        print(f"http://{self.host}:{self.port}/pose_data")
        
        try:
            self.server.serve_forever()
        except KeyboardInterrupt:
            print("서버를 종료합니다.")
        finally:
            self.stop_server()
    
    def start_server_thread(self):
        """별도 스레드에서 서버 시작"""
        self.server_thread = threading.Thread(target=self.start_server, daemon=True)
        self.server_thread.start()
    
    def stop_server(self):
        """서버 종료"""
        self.running = False
        if self.server:
            self.server.shutdown()
            self.server.server_close()
    
    def is_connected(self):
        """연결 상태 확인"""
        return self.connected and (time.time() - self.last_request_time) < 5.0

def main():
    print("Godot 연동 서버를 시작합니다...")
    
    try:
        # 카메라 초기화
        camera = Camera()
        
        # Pygame 초기화 (캘리브레이션용)
        pygame.init()
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN if FULLSCREEN else 0)
        pygame.display.set_caption("Godot 연동 서버")
        
        # 캘리브레이션
        print("\n=== 캘리브레이션 시작 ===")
        homography = calibrate_projector(camera, screen)
        
        if homography is None:
            print("캘리브레이션이 취소되었습니다. 프로그램을 종료합니다.")
            return
        
        # 서버 시작
        pose_server = GodotPoseServer(camera)
        pose_server.start_server_thread()
        
        print("\n=== 서버 실행 중 ===")
        print("Godot에서 포즈 데이터를 받아갈 수 있습니다.")
        print("Ctrl+C를 눌러서 서버를 종료하세요.")
        
        # 비동기 메인 루프 (Pygame 이벤트 처리 포함)
        try:
            clock = pygame.time.Clock()
            running = True
            
            while running:
                # Pygame 이벤트 처리
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            running = False
                
                # 화면 업데이트 (선택사항)
                screen.fill((0, 0, 0))
                
                # 상태 표시
                font = pygame.font.Font(None, 36)
                status_text = f"서버 실행 중 - {pose_server.host}:{pose_server.port}"
                text_surface = font.render(status_text, True, (255, 255, 255))
                screen.blit(text_surface, (50, 50))
                
                # 연결 상태 표시
                if pose_server.is_connected():
                    conn_text = "연결됨"
                    conn_color = (0, 255, 0)
                else:
                    conn_text = "연결 대기 중..."
                    conn_color = (255, 255, 0)
                
                conn_surface = font.render(conn_text, True, conn_color)
                screen.blit(conn_surface, (50, 100))
                
                pygame.display.flip()
                clock.tick(30)  # 30 FPS로 제한
                
        except KeyboardInterrupt:
            print("\n서버를 종료합니다...")
        
    except Exception as e:
        print(f"오류 발생: {e}")
    finally:
        if 'pose_server' in locals():
            pose_server.stop_server()
        if 'camera' in locals():
            camera.release()
        pygame.quit()

if __name__ == "__main__":
    main() 